package DirectTutorials;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class WaitForElement {
 public static void main(String[] args) {
	 System.setProperty("webdriver.chrome.driver", "E:\\drivers\\chromedriver_win32\\chromedriver.exe");
		WebDriver wd;
		wd = new ChromeDriver();
		wd.manage().window().maximize();
		
		wd.get("https://verifalia.com/validate-email");
		
	WebElement email = wd.findElement(By.xpath("//input[@name='inputData']"));
	WebElement validateBtn = wd.findElement(By.xpath("//button[text()='Validate']"));
		
	System.out.println("***Before Entering email field****");
	System.out.println(validateBtn.isEnabled()+"***"+validateBtn.isDisplayed());
	email.sendKeys("kbtutorials");
	validateBtn.click();
	validateBtn.click();
	System.out.println("****After entering ****");
	System.out.println(validateBtn.isEnabled()+"***"+validateBtn.isDisplayed());
	WebDriverWait wait = new WebDriverWait(wd,50);
	WebElement message = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h4[contains(text(),'Complete')]")));
	System.out.println(message.getText());
	
	
		
		
 }
}
