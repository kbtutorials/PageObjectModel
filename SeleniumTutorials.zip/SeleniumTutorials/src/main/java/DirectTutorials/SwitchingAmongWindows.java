package DirectTutorials;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchingAmongWindows {

public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", ".//driver//chromedriver.exe");
	WebDriver wd = new ChromeDriver();
	wd.get("https://www.kotak.com/en.html");
	wd.manage().window().maximize();
	
	//Current window handle
	
	String chandle = wd.getWindowHandle();
	System.out.println("Current window Handle is :"+chandle);
	wd.findElement(By.xpath("//span[text()='Login']")).click();
	
	System.out.println("After clicking Window handle :"+wd.getWindowHandle());
	wd.findElement(By.xpath("//a[text()='Know more']")).click();
	
	Set<String> handles =wd.getWindowHandles();
	Iterator it = handles.iterator();
	String newHandle =null;
	String handle=null;
	while(it.hasNext()) {
		handle = it.next().toString();
		System.out.println(handle);
		if(chandle.contentEquals(handle)) {
			
		}else {
			newHandle =handle;
		}
	}
	
	wd.switchTo().window(newHandle);
	wd.switchTo().frame("framemain");
	wd.findElement(By.id("Username")).sendKeys("123");
	wd.switchTo().window(chandle);
}
}