package DirectTutorials;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class BrowserNavigateDemo {

public static WebDriver wd;	
@BeforeTest	
public void loadDriver() {
	System.setProperty("webdriver.chrome.driver", ".//driver//chromedriver.exe");
	wd= new ChromeDriver();
}
	
@Test
public void browserDemo() {
	wd.get("https://www.google.com");
	
	wd.navigate().to("https://www.facebook.com");
	String title= wd.getTitle();
	System.out.println(title+"***");
	wd.navigate().back();
	wd.navigate().forward();
	Assert.assertEquals(title, wd.getTitle());
	
}

}
