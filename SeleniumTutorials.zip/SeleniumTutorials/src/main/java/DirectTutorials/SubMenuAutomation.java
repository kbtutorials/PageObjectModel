package DirectTutorials;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SubMenuAutomation {
	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "E:\\drivers\\chromedriver_win32\\chromedriver.exe");
			WebDriver wd;
			wd = new ChromeDriver();
			wd.manage().window().maximize();
			wd.get("https://www.oyorooms.com/");
			
			WebElement target =wd.findElement(By.xpath("//h2[text()='Bangalore']"));
			WebElement targ1 = wd.findElement(By.xpath("//a[text()='Koramangala']"));
			Actions s = new Actions(wd);
			s.moveToElement(target);
			s.click(targ1);
			s.build().perform();
			
	}

}
