package DirectTutorials;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelReadingUsingDataProvider {


	
@Test(dataProvider="getData")
public void Testcase(String index,String row) {
	System.out.println(index +" ***** "+row);
	
}
	
	
@SuppressWarnings("null")
@DataProvider(name="getData")	
public Object[][] getData() throws IOException{
	
	Sheet sh = getSheet("input");
	int cellIndex = getColIndex("Execution");
	int index=0;
	Object[][] res = null;
	
	String executionFlag;
	int lastRow = sh.getLastRowNum();
	res = new Object[lastRow][2];
	Row r ;
	for(int i=0;i<=lastRow;i++) {
	   r = sh.getRow(i);
	   executionFlag = r.getCell(cellIndex).toString();
	   if(executionFlag.contentEquals("Y")) {
		   res[index][0]=i;
		   index++;
	   }
	   
	}
	
	
	
	
	return res;
	
}


public static int getColIndex(String s) throws IOException {
	
	Sheet sheet = getSheet("input");
	String cell;
	int index = 0;
	Row r =sheet.getRow(0);
	int lastCell = r.getLastCellNum();
	for(int i=0;i<lastCell;i++) {
		cell = r.getCell(i).toString();
		if(cell.contentEquals(s)) {
			index =i;
			break;
		}
	}
	
	
	
	return index;
	
}

public static Sheet getSheet(String s) throws IOException {
	File f = new File(".//input//inputSheet.xlsx");
	FileInputStream fis = new FileInputStream(f);
	
	
	Workbook wd = new XSSFWorkbook(fis);
	Sheet sh = wd.getSheet(s);
	return sh;
}


}
