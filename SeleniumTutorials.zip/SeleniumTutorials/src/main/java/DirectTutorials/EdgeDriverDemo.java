package DirectTutorials;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class EdgeDriverDemo {
public static void main(String[] args) {
	System.setProperty("webdriver.edge.driver", "C:\\Windows\\System32\\MicrosoftWebDriver.exe");
	WebDriver wd = new EdgeDriver();
	wd.get("https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/");
}
}
