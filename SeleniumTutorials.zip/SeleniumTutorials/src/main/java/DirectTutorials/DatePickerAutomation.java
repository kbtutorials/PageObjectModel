package DirectTutorials;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DatePickerAutomation {
	public static WebDriver wd;
 public static void main(String[] args) {
	 
	 String expectedDate= "15-April-2020";
	 String emonth = expectedDate.split("-")[1];
	 String eyear = expectedDate.split("-")[2];
	 String edate = expectedDate.split("-")[0];
	 System.out.println(emonth+"***"+eyear+"***"+edate);
	 
	 System.setProperty("webdriver.chrome.driver", "E:\\drivers\\chromedriver_win32\\chromedriver.exe");
		
		wd = new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.spicejet.com/");
		wd.manage().timeouts().pageLoadTimeout(180, TimeUnit.SECONDS);
		
		WebDriverWait wait = new WebDriverWait(wd,3000);
		WebElement dateBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@class='ui-datepicker-trigger'])[1]")));
		dateBtn.click();
		
		String cmonth=wd.findElement(By.xpath("(//span[@class='ui-datepicker-month'])[1]")).getText().trim();
		String cyear=wd.findElement(By.xpath("(//span[@class='ui-datepicker-year'])[1]")).getText().trim();
		WebElement next;
		
		
		while( (!cmonth.equals(emonth)) || (!cyear.equals(eyear))) {
			
			next = wd.findElement(By.xpath("//span[text()='Next']"));
			next.click();
			cmonth=wd.findElement(By.xpath("(//span[@class='ui-datepicker-month'])[1]")).getText().trim();
			 cyear=wd.findElement(By.xpath("(//span[@class='ui-datepicker-year'])[1]")).getText().trim();
			
		}
		List<WebElement> dates = wd.findElements(By.xpath("//a[@class='ui-state-default']"));
		
		for(WebElement e :dates) {
			if(e.getText().trim().equals(edate)) {
				e.click();
				break;
			}
		}
		
		
	 
 }
	
	
}
