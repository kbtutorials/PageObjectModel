package DirectTutorials;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelAutomation {
  public static void main(String[] args) throws IOException {
	  File f = new File(".//input/inputSheet.xlsx");
	  FileInputStream fis = new FileInputStream(f);
	  Workbook w;
	  
	  w = new XSSFWorkbook(fis);
	  Sheet s = w.getSheet("input");
	  int rows = s.getLastRowNum();
	 // System.out.println("***Last Row number ***"+rows);
	  for(int i=0;i<=rows;i++) {
		  Row row = s.getRow(i);
		 // System.out.println(row.getLastCellNum()+"***"+i);
		  
		  for(int j=0;j<row.getLastCellNum();j++) {
			  System.out.print(row.getCell(j) +"   ");
		  }
		  System.out.println();
	  }
	  
	  
  }
}
