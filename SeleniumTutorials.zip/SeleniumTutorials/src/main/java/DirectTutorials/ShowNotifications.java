package DirectTutorials;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ShowNotifications {
	static WebDriver wd;
	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "E:\\drivers\\chromedriver_win32\\chromedriver.exe");
			
		 ChromeOptions options = new ChromeOptions();
		// options.addArguments("--disable-notifications");
	
			wd = new ChromeDriver(options);
			wd.manage().window().maximize();
			wd.get("https://www.flipkart.com/");
			wd.findElement(By.xpath("//button[contains(@class,\"_2AkmmA _29YdH8\")]")).click();
			wd.findElement(By.xpath("//input[@name='q']")).sendKeys("Selenium Web Driver books"+Keys.ENTER);
			
	}
}
