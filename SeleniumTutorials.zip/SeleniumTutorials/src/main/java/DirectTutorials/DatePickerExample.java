package DirectTutorials;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DatePickerExample {
	static WebDriver wd;
	public static void main(String[] args) throws InterruptedException {
		String expectedDate = "11-July-2020";
		String edate = expectedDate.split("-")[0];
		String emonth = expectedDate.split("-")[1];
		String eyear = expectedDate.split("-")[2];
		System.out.println(edate+"***"+emonth+"***"+eyear);
		
		
		 System.setProperty("webdriver.chrome.driver", "E:\\drivers\\chromedriver_win32\\chromedriver.exe");
			
			wd = new ChromeDriver();
			wd.manage().window().maximize();
			wd.get("https://www.spicejet.com/");
			wd.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
			//Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(wd,200);
			WebElement eBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@class='ui-datepicker-trigger'])[1]")));
		   eBtn.click();
		   WebElement month = wd.findElement(By.xpath("(//span[@class='ui-datepicker-month'])[1]"));
		   String cmonth=month.getText();
		   WebElement year = wd.findElement(By.xpath("(//span[@class='ui-datepicker-year'])[1]"));
		   String cyear = year.getText();
		   WebElement next = wd.findElement(By.xpath("//span[text()='Next']"));
		   System.out.println(cmonth+"***"+cyear);
		   
		   while(!(cmonth.equals(emonth)) ||(! cyear.equals(eyear))) {
			   next = wd.findElement(By.xpath("//span[text()='Next']"));
			   next.click();
			   cmonth=wd.findElement(By.xpath("(//span[@class='ui-datepicker-month'])[1]")).getText();
			   cyear= wd.findElement(By.xpath("(//span[@class='ui-datepicker-year'])[1]")).getText();
			   System.out.println(cmonth+"***"+emonth+"***"+cyear+"***"+eyear+"***"+(cmonth.equals(emonth) && cyear.equals(eyear))+"");
		   }
		   
		   List<WebElement> dates = wd.findElements(By.xpath("//a[@class='ui-state-default']"));
		   
		   for(WebElement e :dates) {
			   if(e.getText().trim().equals(edate)) {
				   e.click();
				   break;
			   }
		   }
		   
		   
		   
			
	}
	
	public static void datePicker(WebElement el ,String dateValue) {
		JavascriptExecutor js = (JavascriptExecutor)wd;
		js.executeScript("arguments[0].setAttribute('value','"+dateValue+"');", el);
	}
	
}
