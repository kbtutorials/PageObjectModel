package PageObjectModel;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

@FindBy(xpath="//button[contains(@class,'_2AkmmA _29YdH8')]")
WebElement closeBtn;

public static  String s = "Hello world";
@FindBy(xpath="//input[@name='q']")
WebElement searchBar;



public void CloseBtn() {
	closeBtn.click();
}
	
public void load(WebDriver wd) {
	PageFactory.initElements(wd,this);
}
	
public void searchQuery(String search) {
	searchBar.sendKeys(search+Keys.ENTER);
}	

public HomePage(WebDriver wd) {
	//PageFactory.initElements(wd, this);
}

	
}
