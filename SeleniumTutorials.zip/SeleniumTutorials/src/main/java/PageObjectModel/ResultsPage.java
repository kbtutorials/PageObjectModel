package PageObjectModel;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ResultsPage {

@FindBy(xpath="//a[@class='_2cLu-l']")
List<WebElement> results;
	

public int countOfResults() {
	return results.size();
}

public ResultsPage(WebDriver wd) {
	PageFactory.initElements(wd, this);
}

public void getTitles() {
	for(WebElement res:results) {
		System.out.println(res.getAttribute("title"));
	}
}

	
}
