package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



public class ValidationsClass {
	
	
public static WebDriver wd;
public static String url ="https://www.flipkart.com/";
public static HomePage home;
public static ResultsPage rs;


@BeforeClass
public static void Intializa() {
	System.setProperty("webdriver.chrome.driver", ".\\driver\\chromedriver.exe");
	wd = new ChromeDriver();
	wd.manage().window().maximize();
	wd.get(url);
	home.s ="Selenium";
	home = new HomePage(wd);
	rs = new ResultsPage(wd);
	
	
}

@Test
public void Validations() throws InterruptedException {
	
    home.load(wd);
	
	System.out.println("***"+home.s);
	home.CloseBtn();
	home.searchQuery("Selenium Web Driver");
	Thread.sleep(5000);
	
	Assert.assertEquals(20, rs.countOfResults());
	rs.countOfResults();
	System.out.println(rs.countOfResults());
	rs.getTitles();
	
	
}
}
